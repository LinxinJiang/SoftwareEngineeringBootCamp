What we've done:
  changed state facts drop down to show animal stats
    -need to update images
  changed the js file from state facts to specifics about the animal
  modified the form at the bottom
  changed history text
  center the : main role="main"


  changed background color
  changed inner wrapper color