var stateData = {
	cat1: {
		name: " ",
		weight: '2 lbs',
		age: '6 months',
		color: 'White',
	},
	cat2: {
		name: " ",
		weight: '13 oz',
		age: '2 months',
		color: 'Grey and White',
	},
	cat3: {
		name: " ",
		weight: '4 lbs',
		age: '2 years',
		color: 'Orange',
	},
	dog1: {
		name: " ",
		weight: '22 lbs',
		age: '6 year',
		color: 'Brown',
	},
	dog2: {
		name: " ",
		weight: '6 lbs',
		age: '12 months',
		color: 'White, Brown, and Black',
	},
	dog3: {
		name: " ",
		weight: '5 lbs',
		age: '11 months',
		color: 'Brown and White',
	}
};